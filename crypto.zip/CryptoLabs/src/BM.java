import java.math.BigInteger;
import java.util.Arrays;
import java.util.Random;

public class BM {
	public static BigInteger generateSequenceOfBits(int length) {
		byte [] bit= new byte [length];
		String p1 = "93466510612868436543809057926265637055082661966786875228460721852868821292003";
		String a1 = "41402113656871763270073938229168765778879686959780184368336806110280536326998";
		BigInteger p = new BigInteger(p1, 16);
		BigInteger a = new BigInteger(a1, 16);
		BigInteger P=(p.subtract(BigInteger.valueOf(1))).divide(BigInteger.valueOf(2));
		Random r = new Random();
		BigInteger T0=BigInteger.valueOf(r.nextLong());
		BigInteger Ti=T0;
		
		for (int i=0;i<length;i++){
			Ti=Ti.mod(p);
		
			if (Ti.compareTo(P)==-1) bit[i]=1;
			else bit[i]=0;	
			Ti=a.modPow(Ti, p);
		}
		System.out.println("Sequence is ready");
		
		StringBuilder builder = new StringBuilder();
		for (byte value : bit) {
		    builder.append(value);
		}
		String text = builder.toString();
		
		/*BigInteger number = new BigInteger("0",2);
		BigInteger two = new BigInteger("2");
		for (int i=0; i<length; i++){
			System.out.println("Step "+i);
			if (bit[i]==1)
			number = number.add(two).pow(i);
		}*/
		System.out.println(text);
		BigInteger number = new BigInteger(text,2);
		System.out.println();
		System.out.println("Bit sequence : "+Arrays.toString(bit) );
		System.out.println("bit length: "+ bit.length);
		System.out.println("Random number "+number);
		return number;
	}
	

}