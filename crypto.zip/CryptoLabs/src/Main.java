import java.math.BigInteger;
import java.util.Arrays;
import java.util.Random;


public class Main {

	public static void main(String[] args) {
		//BM.generateSequenceOfBits(2048);
		//short sequence[] =BMmod.generateSequenceOfByte(2048);
		//System.out.println(sequence.length +" "+Arrays.toString(sequence));
		//System.currentTimeMillis()
		Random random = new Random();
		long start = System.currentTimeMillis();
		MaurerAlgorithm maurerAlgorithm = new MaurerAlgorithm(random);
        BigInteger prime = maurerAlgorithm.generatePrime(1024);
        long finish = System.currentTimeMillis();
		long timeConsumedMillis = finish - start;
        System.out.println(prime);
        System.out.println("Generation time in miliseconds "+ timeConsumedMillis);
        System.out.println(prime.isProbablePrime(100));
	}

}
