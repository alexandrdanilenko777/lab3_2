
import java.math.BigInteger;
public class BMmod {
	public static short[] generateSequenceOfByte(int length) {
		short sequence[] = new short[length];
		String p1 = "93466510612868436543809057926265637055082661966786875228460721852868821292003";
		String a1 = "41402113656871763270073938229168765778879686959780184368336806110280536326998";
		BigInteger p = new BigInteger(p1, 16);
		BigInteger a = new BigInteger(a1, 16);
		BigInteger pminus1=p.subtract(BigInteger.ONE);
		//BigInteger P=(p.subtract(BigInteger.valueOf(1))).divide(BigInteger.valueOf(2));
		BigInteger T0=BigInteger.valueOf(35803);
		BigInteger elem;
		BigInteger Ti=T0;
		for (int i=0;i<length;i++){
			Ti=a.modPow(Ti, p);
			elem=(Ti.multiply(BigInteger.valueOf(256)).divide(pminus1));
			if (elem.equals(256)==false)  elem.add(BigInteger.ONE);
				sequence[i]=elem.shortValue();		
		}
		System.out.printf("%-20s","Byte modificationBM ");
		return sequence;
	}
}
